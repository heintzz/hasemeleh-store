import React from 'react'

const Series = () => {
  return <div className="h-2 w-[35%] mb-2 bg-slate-200 rounded-lg"></div>
}

export default Series
