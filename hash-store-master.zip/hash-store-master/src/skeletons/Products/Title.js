import React from 'react'

const Title = () => {
  return <div className="h-2 w-[75%] mb-1 bg-slate-200 rounded-lg "></div>
}

export default Title
