import React from 'react'

export default function ItemNotFound () {
  return <h2>gada yagesya</h2>
}
